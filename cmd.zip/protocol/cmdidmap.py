import os

def generate_code(proto_file):
    # 提取消息名
    file_name = os.path.splitext(os.path.basename(proto_file))[0]
    message_name = file_name.split('_')[0]

    # 生成代码
    code = f'c.regMsg({message_name}, func() any {{ return new(proto.{message_name}) }})'

    return code

# 遍历proto文件夹下的所有.proto文件
proto_folder = 'hkrpg'
output_code = ''

for file in os.listdir(proto_folder):
    if file.endswith('.proto'):
        proto_file = os.path.join(proto_folder, file).replace('\\', '/')
        code = generate_code(proto_file)
        output_code += code + '\n'

# 打开文件并写入生成的代码
with open('cmdid.go', 'w') as f:
    f.write(output_code)

# 输出提示信息
print("已将生成的代码输出到文件 'cmdid.go'")
