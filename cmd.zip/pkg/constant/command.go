package constant

const (
	CommAndTest   = 1
	SetWorldLevel = 1001
	GetPlayerDb   = 1002
	Status        = 1003
)
