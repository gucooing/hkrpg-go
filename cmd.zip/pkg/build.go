package pkg

func GetVersion() string {
	return "dev-1.4.0"
}
