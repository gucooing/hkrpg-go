package yuankong

func NewYuanKong() {

}
