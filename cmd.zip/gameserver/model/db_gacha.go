package model

import (
	spb "github.com/gucooing/hkrpg-go/protocol/server"
)

func NewGacha() *spb.Gacha {
	return &spb.Gacha{
		GachaMap: make(map[uint32]*spb.GachaNum),
	}
}

func (g *PlayerData) GetGacha() *spb.Gacha {
	db := g.GetBasicBin()
	if db.Gacha == nil {
		db.Gacha = NewGacha()
	}
	return db.Gacha
}

func (g *PlayerData) GetDbGacha(gachaId uint32) *spb.GachaNum {
	gaCha := g.GetGacha()
	if gaCha.GachaMap == nil {
		gaCha.GachaMap = make(map[uint32]*spb.GachaNum)
	}
	if gaCha.GachaMap[gachaId] == nil {
		gaCha.GachaMap[gachaId] = &spb.GachaNum{
			CeilingNum:               0,
			Pity4:                    0,
			FailedFeaturedItemPulls4: false,
			FailedFeaturedItemPulls5: false,
		}
	}
	return gaCha.GachaMap[gachaId]
}

func (g *PlayerData) AddGachaItem(id uint32, allSync *AllPlayerSync) (bool, bool) {
	var pileItem []*Material
	if id >= 20000 {
		uniqueId := g.AddEquipment(id)
		allSync.EquipmentList = append(allSync.EquipmentList, uniqueId)
		return false, false
	} else {
		if g.GetAvatarBinById(id) != nil {
			allSync.MaterialList = append(allSync.MaterialList, id+10000)
			allSync.MaterialList = append(allSync.MaterialList, 252)
			pileItem = append(pileItem, &Material{
				Tid: id + 10000,
				Num: 1,
			})
			pileItem = append(pileItem, &Material{
				Tid: 252,
				Num: 8,
			})
			g.AddMaterial(pileItem)
			return true, false
		}
		allSync.AvatarList = append(allSync.AvatarList, id)
		g.AddAvatar(id)
		return true, true
	}
}
