package gameserver

import (
	pb "google.golang.org/protobuf/proto"
)

func (s *GameServer) GmGive(serviceMsg pb.Message) {

}

func (s *GameServer) GmWorldLevel(serviceMsg pb.Message) {

}

func (s *GameServer) DelItem(serviceMsg pb.Message) {

}

func (s *GameServer) GmMaxCurAvatar(serviceMsg pb.Message) {

}

func (s *GameServer) GmMission(serviceMsg pb.Message) {

}
